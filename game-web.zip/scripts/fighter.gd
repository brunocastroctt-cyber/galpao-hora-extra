extends CharacterBody3D

const A = preload("res://scripts/assets.gd")
var game
var team := 0
var is_player := false
var nickname := "Funcionário"
var character_config: Dictionary
var character_index := 0
var hp := 100.0
var kills := 0
var deaths := 0
var alive := true
var respawn_time := 0.0
var protection := 1.8
var carried_flag := -1
var camera: Camera3D
var visual: Node3D
var gun: Node3D
var flash: MeshInstance3D
var capsule: CapsuleShape3D
var collider: CollisionShape3D
var loadout: Array[int] = []
var magazines: Array[int] = []
var slot := 0
var fire_timer := 0.0
var reload_timer := 0.0
var burst_left := 0
var burst_timer := 0.0
var trigger_last := false
var pitch := 0.0
var recoil := 0.0
var slide_time := 0.0
var slide_cooldown := 0.0
var slide_vector := Vector3.ZERO
var walk_phase := 0.0
var ai_think := 0.0
var ai_target = null
var ai_path := PackedVector3Array()
var ai_path_index := 0
var ai_repath := 0.0
var ai_stuck := 0.0
var ai_last_pos := Vector3.ZERO
var ai_strafe := 1.0
var network_remote := false
var network_id := 1
var network_target_position := Vector3.ZERO
var network_target_rotation := 0.0
var network_target_pitch := 0.0
var network_move_speed := 0.0

func _ready() -> void:
	collision_layer = 2
	collision_mask = 3
	capsule = CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.8
	collider = CollisionShape3D.new()
	collider.shape = capsule
	collider.position.y = 0.9
	add_child(collider)
	loadout.assign([0, 1, 2] if team == 0 else [3, 4, 5])
	for index in loadout:
		magazines.append(A.WEAPONS[index].mag)
	if is_player:
		camera = Camera3D.new()
		camera.position.y = 1.60
		camera.fov = 78
		camera.near = 0.04
		add_child(camera)
		camera.current = true
		build_gun()
	else:
		visual = A.character(self, character_config, team, character_index == 3)
		var held := A.weapon(visual, loadout[0])
		held.position = Vector3(0, 1.00, -0.52)
		held.rotation_degrees = Vector3(0, 0, 0)
		ai_strafe = -1.0 if randf() < 0.5 else 1.0
		ai_last_pos = position
	network_target_position = position

func weapon() -> Dictionary:
	return A.WEAPONS[loadout[slot]]

func build_gun() -> void:
	if is_instance_valid(gun):
		gun.queue_free()
	gun = A.weapon(camera, loadout[slot])
	gun.position = Vector3(0.34, -0.31, -0.45)
	var left_arm := A.box(gun, Vector3(-0.20, -0.26, 0.09), Vector3(0.18, 0.19, 0.45), character_config.coat)
	left_arm.rotation.x = -0.58
	left_arm.rotation.z = -0.28
	var right_arm := A.box(gun, Vector3(0.16, -0.29, 0.16), Vector3(0.17, 0.19, 0.38), character_config.coat)
	right_arm.rotation.x = -0.66
	right_arm.rotation.z = 0.20
	A.box(gun, Vector3(-0.17, -0.42, -0.09), Vector3(0.13, 0.14, 0.16), character_config.skin)
	A.box(gun, Vector3(0.13, -0.44, 0.00), Vector3(0.13, 0.14, 0.16), character_config.skin)
	flash = A.box(gun, Vector3(0, 0.015, -0.44), Vector3(0.12, 0.12, 0.18), Color("ffcc65"), false, true)
	flash.visible = false

func _physics_process(delta: float) -> void:
	if not game.playing:
		return
	if not alive:
		respawn_time -= delta
		if respawn_time <= 0:
			respawn()
		return
	if network_remote:
		network_step(delta)
		return
	protection = maxf(0.0, protection - delta)
	fire_timer = maxf(0.0, fire_timer - delta)
	slide_cooldown = maxf(0.0, slide_cooldown - delta)
	if reload_timer > 0:
		reload_timer -= delta
		if reload_timer <= 0:
			magazines[slot] = weapon().mag
	if burst_left > 0:
		burst_timer -= delta
		if burst_timer <= 0:
			shoot_round()
			burst_left -= 1
			burst_timer = 0.065
	if is_player:
		player_step(delta)
	else:
		bot_step(delta)
	if not is_on_floor():
		velocity.y -= 24.0 * delta
	move_and_slide()
	if global_position.y < -4:
		take_damage(200, null)

func player_step(delta: float) -> void:
	var move: Vector2 = Input.get_vector("left", "right", "forward", "back")
	if game.hud.move_vector.length() > 0.05:
		move = game.hud.move_vector
	var direction := global_basis * Vector3(move.x, 0, move.y)
	if direction.length() > 1:
		direction = direction.normalized()
	var wants_jump: bool = Input.is_action_just_pressed("jump") or game.hud.jump_requested
	var wants_slide: bool = Input.is_action_just_pressed("slide") or game.hud.slide_requested
	game.hud.jump_requested = false
	game.hud.slide_requested = false
	if wants_slide and is_on_floor() and direction.length() > 0.3 and slide_cooldown <= 0:
		slide_time = 0.7
		slide_cooldown = 1.3
		slide_vector = direction.normalized()
		capsule.height = 1.0
		collider.position.y = 0.5
	if wants_jump and is_on_floor():
		velocity.y = 8.0
		slide_time = 0
	if slide_time > 0:
		slide_time -= delta
		velocity.x = slide_vector.x * (8.0 + slide_time * 6)
		velocity.z = slide_vector.z * (8.0 + slide_time * 6)
	else:
		var can_stand := true
		if capsule.height < 1.8:
			var query := PhysicsRayQueryParameters3D.create(global_position + Vector3.UP * 0.7, global_position + Vector3.UP * 1.9, 1, [get_rid()])
			can_stand = get_world_3d().direct_space_state.intersect_ray(query).is_empty()
		if can_stand:
			capsule.height = 1.8
			collider.position.y = 0.9
		var speed := 6.8 if can_stand else 3.0
		velocity.x = move_toward(velocity.x, direction.x * speed, delta * 32)
		velocity.z = move_toward(velocity.z, direction.z * speed, delta * 32)
	var trigger: bool = game.desktop_fire or game.hud.fire_held
	if trigger and (weapon().auto or not trigger_last):
		try_fire()
	trigger_last = trigger
	if Input.is_action_just_pressed("reload"):
		reload_weapon()
	if Input.is_action_just_pressed("swap"):
		switch_weapon()
	walk_phase += Vector2(velocity.x, velocity.z).length() * delta * 1.8
	camera.position.y = lerpf(camera.position.y, 0.85 if capsule.height < 1.8 else 1.60, delta * 14)
	recoil = move_toward(recoil, 0.0, delta * 0.6)
	gun.position = Vector3(0.34, -0.31 + sin(walk_phase) * 0.012 - (0.15 if reload_timer > 0 else 0.0), -0.45 + recoil)
	gun.rotation.x = -0.35 if reload_timer > 0 else recoil * 0.7
	flash.visible = recoil > 0.060
	camera.fov = lerpf(camera.fov, 86.0 if slide_time > 0 else 78.0, delta * 7)

func look(delta: Vector2) -> void:
	if not alive:
		return
	rotation.y -= delta.x * game.sensitivity * 0.0025
	pitch = clampf(pitch - delta.y * game.sensitivity * 0.0025, -1.40, 1.40)
	camera.rotation.x = pitch

func switch_weapon() -> void:
	if not alive:
		return
	slot = (slot + 1) % loadout.size()
	reload_timer = 0
	burst_left = 0
	fire_timer = 0.22
	trigger_last = true
	if is_player:
		build_gun()

func reload_weapon() -> void:
	if alive and reload_timer <= 0 and magazines[slot] < int(weapon().mag) and burst_left == 0:
		reload_timer = weapon().reload
		if is_player:
			game.audio.play_sound("reload", -12)

func try_fire() -> void:
	if fire_timer > 0 or reload_timer > 0 or burst_left > 0 or not alive:
		return
	if magazines[slot] <= 0:
		reload_weapon()
		return
	protection = 0.0
	fire_timer = weapon().rate
	shoot_round()
	burst_left = int(weapon().burst) - 1
	burst_timer = 0.065

func shoot_round() -> void:
	if magazines[slot] <= 0 or not alive:
		return
	magazines[slot] -= 1
	var origin := global_position + Vector3.UP * 1.45
	var direction := -global_basis.z
	if is_player:
		origin = camera.global_position
		direction = -camera.global_basis.z
		recoil = 0.085
		game.audio.play_sound("shot", -9)
	elif is_instance_valid(ai_target):
		direction = (ai_target.global_position + Vector3.UP * 1.15 - origin).normalized()
	var spread: float = weapon().spread if is_player else 0.065
	direction = (direction + Vector3(randf_range(-spread, spread), randf_range(-spread, spread), randf_range(-spread, spread))).normalized()
	var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * 90, 3, [get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	var endpoint := origin + direction * 55
	if not hit.is_empty():
		endpoint = hit.position
		if hit.collider.has_method("take_damage"):
			var target = hit.collider
			if game.enemies(self, target):
				if game.online_mode and not game.online_host and is_player:
					game.report_online_shot(origin, direction, slot)
				else:
					var head: bool = hit.position.y - target.global_position.y > 1.43
					target.take_damage(float(weapon().damage) * (1.6 if head else 1.0), self)
					if is_player and target.protection <= 0:
						game.hud.hit_timer = 0.14
						game.audio.play_sound("hit", -12)
	game.tracer(origin + direction * 0.6, endpoint, team)

func take_damage(amount: float, attacker) -> void:
	if not alive or protection > 0:
		return
	hp = maxf(0.0, hp - amount)
	if is_player:
		game.hud.damage_timer = 0.32
	if hp <= 0:
		alive = false
		deaths += 1
		respawn_time = 3
		velocity = Vector3.ZERO
		burst_left = 0
		reload_timer = 0
		collision_layer = 0
		if visual:
			visual.visible = false
		if is_player:
			gun.visible = false
		game.actor_died(self, attacker)

func respawn() -> void:
	alive = true
	hp = 100
	protection = 1.8
	collision_layer = 2
	position = game.choose_spawn(self)
	rotation.y = -PI / 2 if team == 0 else PI / 2
	velocity = Vector3.ZERO
	slide_time = 0
	capsule.height = 1.8
	collider.position.y = 0.9
	for i in range(magazines.size()):
		magazines[i] = A.WEAPONS[loadout[i]].mag
	if visual:
		visual.visible = true
	if is_player:
		gun.visible = true
		pitch = 0
		camera.rotation.x = 0
	ai_target = null
	ai_path.clear()
	ai_repath = 0

func bot_step(delta: float) -> void:
	ai_think -= delta
	ai_repath -= delta
	if ai_think <= 0:
		ai_think = randf_range(0.18, 0.30)
		ai_target = null
		var nearest := 32.0
		for other in game.actors:
			if other == self or not other.alive or not game.enemies(self, other):
				continue
			var distance: float = global_position.distance_to(other.global_position)
			if distance < nearest and can_see(other):
				nearest = distance
				ai_target = other
	var goal: Vector3 = game.bot_goal(self)
	var engage: bool = is_instance_valid(ai_target) and ai_target.alive
	if engage:
		var toward: Vector3 = ai_target.global_position - global_position
		rotation.y = lerp_angle(rotation.y, atan2(-toward.x, -toward.z), delta * 8)
		if can_see(ai_target):
			try_fire()
		if game.mode != 2:
			goal = ai_target.global_position
	if ai_repath <= 0:
		ai_repath = randf_range(0.7, 1.1)
		ai_path = game.find_path(position, goal)
		ai_path_index = 1 if ai_path.size() > 1 else 0
	var move := Vector3.ZERO
	if ai_path_index < ai_path.size():
		var offset: Vector3 = ai_path[ai_path_index] - position
		offset.y = 0
		if offset.length() < 0.7:
			ai_path_index += 1
		else:
			move = offset.normalized()
	if engage and game.mode != 2 and position.distance_to(ai_target.position) < 10:
		move = global_basis.x * ai_strafe * 0.55
	if move.length() > 0.1 and not engage:
		rotation.y = lerp_angle(rotation.y, atan2(-move.x, -move.z), delta * 7)
	velocity.x = move.x * 4.0
	velocity.z = move.z * 4.0
	ai_stuck += delta
	if ai_stuck > 1.0:
		if position.distance_to(ai_last_pos) < 0.45:
			ai_strafe *= -1
			ai_repath = 0
			if is_on_floor():
				velocity.y = 7
		ai_last_pos = position
		ai_stuck = 0
	if magazines[slot] <= 0:
		reload_weapon()
	var stride := sin(Time.get_ticks_msec() * 0.012) * move.length()
	visual.rotation.z = stride * 0.025
	visual.get_node("LegL").rotation.x = stride * 0.55
	visual.get_node("LegR").rotation.x = -stride * 0.55
	visual.get_node("ArmL").rotation.x = -stride * 0.08
	visual.get_node("ArmR").rotation.x = stride * 0.08

func network_step(delta: float) -> void:
	var previous := position
	position = position.lerp(network_target_position, minf(1.0, delta * 15.0))
	rotation.y = lerp_angle(rotation.y, network_target_rotation, minf(1.0, delta * 15.0))
	network_move_speed = previous.distance_to(position) / maxf(delta, 0.001)
	if visual:
		var stride := sin(Time.get_ticks_msec() * 0.015) * clampf(network_move_speed / 4.0, 0.0, 1.0)
		visual.rotation.z = stride * 0.025
		visual.get_node("LegL").rotation.x = stride * 0.55
		visual.get_node("LegR").rotation.x = -stride * 0.55

func apply_network_state(state: Dictionary, local_client: bool) -> void:
	var state_alive: bool = state.get("alive", true)
	hp = float(state.get("hp", hp))
	kills = int(state.get("kills", kills))
	deaths = int(state.get("deaths", deaths))
	carried_flag = int(state.get("flag", carried_flag))
	if network_remote:
		network_target_position = state.get("position", position)
		network_target_rotation = float(state.get("rotation", rotation.y))
	elif local_client:
		if position.distance_to(state.get("position", position)) > 2.0:
			position = state.get("position", position)
		rotation.y = float(state.get("rotation", rotation.y))
	if state_alive != alive:
		alive = state_alive
		collision_layer = 2 if alive else 0
		if visual:
			visual.visible = alive
		if is_player and is_instance_valid(gun):
			gun.visible = alive
		if not alive:
			respawn_time = 3.0

func can_see(other) -> bool:
	var query := PhysicsRayQueryParameters3D.create(global_position + Vector3.UP * 1.5, other.global_position + Vector3.UP * 1.3, 3, [get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return not hit.is_empty() and hit.collider == other
