extends Node

var sounds: Dictionary = {}
var voices: Array[AudioStreamPlayer] = []
var cursor := 0

func _ready() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 707
	for kind in ["shot", "hit", "reload", "capture"]:
		var wav := AudioStreamWAV.new()
		wav.format = AudioStreamWAV.FORMAT_16_BITS
		wav.mix_rate = 22050
		var duration := 0.10 if kind == "shot" else 0.18
		var samples := int(duration * 22050)
		var bytes := PackedByteArray()
		bytes.resize(samples * 2)
		for i in range(samples):
			var t := float(i) / 22050.0
			var envelope := pow(1.0 - float(i) / samples, 2)
			var value := 0.0
			match kind:
				"shot": value = (rng.randf_range(-1, 1) * 0.65 + sin(t * 680) * 0.35) * envelope
				"hit": value = sin(TAU * 1300 * t) * envelope * 0.4
				"reload": value = rng.randf_range(-1, 1) * envelope * (0.35 if i % 1600 < 400 else 0.03)
				"capture": value = sin(TAU * (660 if t < 0.09 else 990) * t) * envelope * 0.5
			bytes.encode_s16(i * 2, int(value * 26000))
		wav.data = bytes
		sounds[kind] = wav
	for i in range(8):
		var voice := AudioStreamPlayer.new()
		add_child(voice)
		voices.append(voice)

func play_sound(kind: String, volume: float = -10) -> void:
	var voice := voices[cursor]
	cursor = (cursor + 1) % voices.size()
	voice.stream = sounds[kind]
	voice.volume_db = volume
	voice.play()
