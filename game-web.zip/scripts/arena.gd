extends Node3D

const A = preload("res://scripts/assets.gd")
var obstacles: Array[Rect2] = []
var sun: DirectionalLight3D
var spawn_points := [Vector3(-24, 0.1, -12), Vector3(24, 0.1, 12)]

func _ready() -> void:
	var environment := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("71808a")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("d3e0e8")
	env.ambient_light_energy = 0.72
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.environment = env
	add_child(environment)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-65, -30, 0)
	sun.light_energy = 1.35
	sun.light_color = Color("fff1d8")
	add_child(sun)
	A.box(self, Vector3(0, -0.2, 0), Vector3(60, 0.4, 42), Color("787c78"), true)
	for z in [-21, 21]:
		A.box(self, Vector3(0, 4.5, z), Vector3(60, 9, 0.5), Color("bab6a8"), true)
		A.box(self, Vector3(0, 1.0, z * 0.987), Vector3(60, 2, 0.03), Color("536d72"))
	for x in [-30, 30]:
		A.box(self, Vector3(x, 4.5, 0), Vector3(0.5, 9, 42), Color("bbb9ac"), true)
		A.box(self, Vector3(x * 0.99, 2.3, 0), Vector3(0.05, 4.6, 7), Color("5c6769"))
		for z in range(-3, 4):
			A.box(self, Vector3(x * 0.988, 2.3, z), Vector3(0.06, 4.6, 0.05), Color("3d5155"))
	# Open clerestory bands and a complete lightweight roof.
	A.box(self, Vector3(0, 9.1, 0), Vector3(60, 0.2, 42), Color("6b7477"))
	for x in range(-24, 25, 8):
		A.box(self, Vector3(x, 8.7, 0), Vector3(0.22, 0.45, 42), Color("414f56"))
		for z in [-13, 0, 13]:
			A.box(self, Vector3(x, 8.42, z), Vector3(2.8, 0.07, 0.36), Color("fff6d2"), false, true)
		for z in [-20, 20]:
			A.box(self, Vector3(x, 4.2, z), Vector3(0.5, 8.4, 0.5), Color("4f6266"), true)
	for x in [-20, -10, 0, 10, 20]:
		A.box(self, Vector3(x, 0.012, 0), Vector3(0.07, 0.015, 38), Color("c9b47d"))
	for i in range(2):
		var p: Vector3 = spawn_points[i]
		A.box(self, p - Vector3(0, 0.083, 0), Vector3(7, 0.035, 7), A.RED if i == 0 else A.BLUE)
		sign_text("EXPEDIÇÃO" if i == 0 else "RECEBIMENTO", Vector3(p.x, 4.5, -20.65 if i == 0 else 20.65), 0 if i == 0 else PI, A.RED if i == 0 else A.BLUE)
	van(Vector3(-12, 0, -5), 0.16)
	van(Vector3(12, 0, 5), PI + 0.16)
	van(Vector3(0, 0, -14), PI / 2)
	for p in [Vector3(-5, 0, 4), Vector3(6, 0, -4), Vector3(-18, 0, 9), Vector3(18, 0, -9), Vector3(0, 0, 13)]:
		pallet_stack(p, 5)
	for p in [Vector3(-9, 0, 13), Vector3(9, 0, -13), Vector3(-20, 0, -3), Vector3(20, 0, 3)]:
		crate(p)
	sign_text("GALPÃO 07   /   HORA EXTRA", Vector3(0, 5.7, -20.65), 0, Color("f4ead8"))
	sign_text("NÃO BUZINE. A FIORINO NÃO PEGA.", Vector3(0, 5.7, 20.65), PI, Color("f4ead8"))

func sign_text(text: String, pos: Vector3, yaw: float, color: Color) -> void:
	var label := Label3D.new()
	label.text = text
	label.font_size = 64
	label.pixel_size = 0.013
	label.modulate = color
	label.outline_size = 6
	add_child(label)
	label.position = pos
	label.rotation.y = yaw

func pallet_stack(pos: Vector3, count: int) -> void:
	obstacles.append(Rect2(Vector2(pos.x - 1.8, pos.z - 1.5), Vector2(3.6, 3)))
	var root := Node3D.new()
	add_child(root)
	root.position = pos
	# One collision per stack; slats are visual only.
	var body := StaticBody3D.new()
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(3, count * 0.32, 2.4)
	collision.shape = shape
	collision.position.y = shape.size.y / 2
	body.add_child(collision)
	root.add_child(body)
	for level in range(count):
		for side in [-1, 1]:
			A.box(root, Vector3(side, 0.12 + level * 0.32, 0), Vector3(0.2, 0.24, 2.4), Color("8b6b47"))
		for slat in range(5):
			A.box(root, Vector3(0, 0.28 + level * 0.32, -0.96 + slat * 0.48), Vector3(3, 0.08, 0.34), Color("b79662"))

func crate(pos: Vector3) -> void:
	obstacles.append(Rect2(Vector2(pos.x - 1.7, pos.z - 1.7), Vector2(3.4, 3.4)))
	A.box(self, pos + Vector3(0, 1.1, 0), Vector3(2.8, 2.2, 2.8), Color("a08d6c"), true)
	for z in [-1.41, 1.41]:
		A.box(self, pos + Vector3(0, 1.1, z), Vector3(0.2, 2.2, 0.02), Color("4b575b"))

func van(pos: Vector3, yaw: float) -> void:
	var root := Node3D.new()
	add_child(root)
	root.position = pos
	root.rotation.y = yaw
	var extent := Vector2(2.2, 3.8) if absf(sin(yaw)) < 0.5 else Vector2(3.8, 2.2)
	obstacles.append(Rect2(Vector2(pos.x, pos.z) - extent, extent * 2))
	var ivory := Color("ccc8b8")
	A.box(root, Vector3(0, 1, 0), Vector3(2.9, 1.3, 5.6), ivory, true)
	A.box(root, Vector3(0, 2.05, 0.85), Vector3(2.8, 1.2, 3.7), ivory, true)
	A.box(root, Vector3(0, 1.82, -1.13), Vector3(2.7, 0.86, 1.1), Color("455d67"), true)
	A.box(root, Vector3(0, 1.06, -2.86), Vector3(1.7, 0.33, 0.1), Color("3d4649"))
	for side in [-1, 1]:
		A.box(root, Vector3(side * 1.08, 1.28, -2.86), Vector3(0.46, 0.24, 0.12), Color("e1d29a"))
		for z in [-1.8, 1.8]:
			sphere_wheel(root, Vector3(side * 1.42, 0.46, z))
	A.box(root, Vector3(-0.7, 1.68, 2.71), Vector3(0.72, 0.33, 0.025), Color("86634d"))
	var hood := A.box(root, Vector3(0, 1.74, -2.20), Vector3(2.6, 0.1, 1.4), Color("aaa898"))
	hood.rotation.x = -0.40

func sphere_wheel(parent: Node3D, pos: Vector3) -> void:
	var wheel := A.sphere(parent, pos, 0.49, Color("252c30"))
	wheel.scale.x = 0.45
