extends Node3D

const A = preload("res://scripts/assets.gd")
const Arena = preload("res://scripts/arena.gd")
const Fighter = preload("res://scripts/fighter.gd")
const Hud = preload("res://scripts/hud.gd")
const Sound = preload("res://scripts/sound.gd")
const ONLINE_PORT := 24884
const PUBLIC_SERVER_URL := "wss://galpao-hora-extra.onrender.com"
var arena
var hud
var audio
var player
var actors: Array = []
var layer: CanvasLayer
var menu: Control
var menu_camera: Camera3D
var preview: Node3D
var playing := false
var desktop_fire := false
var mode := 1
var selected_team := 0
var selected_character := 0
var custom_character: Dictionary = A.PRESETS[0].duplicate(true)
var player_name := "Você"
var sensitivity := 1.0
var graphics := 1
var master_volume := 0.7
var time_left := 240.0
var scores := [0, 0]
var notice_text := ""
var notice_timer := 0.0
var navigation := AStarGrid2D.new()
var flags: Array = []
var traces: Array = []
var trace_cursor := 0
var ui_theme: Theme
var settings_path := "user://settings.cfg"
var online_mode := false
var online_host := false
var network_timer := 0.0
var online_status := ""
var dedicated_server := false
var waiting_players: Array = []
var server_port := ONLINE_PORT

func _ready() -> void:
	Engine.max_fps = 60
	create_inputs()
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	create_theme()
	arena = Arena.new()
	add_child(arena)
	build_navigation()
	audio = Sound.new()
	add_child(audio)
	layer = CanvasLayer.new()
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	hud = Hud.new()
	hud.game = self
	layer.add_child(hud)
	load_settings()
	apply_graphics()
	menu_camera = Camera3D.new()
	add_child(menu_camera)
	menu_camera.position = Vector3(0, 2.3, 12)
	menu_camera.look_at(Vector3(0, 2.3, 0))
	menu_camera.fov = 65
	create_flags()
	for i in range(24):
		var beam := A.box(self, Vector3.ZERO, Vector3(0.025, 0.025, 1), Color("fce7a2"), false, true)
		beam.visible = false
		traces.append({"mesh": beam, "time": 0.0})
	if "--server" in OS.get_cmdline_args():
		start_dedicated_server()
		return
	show_main_menu()

func create_inputs() -> void:
	var actions := {"forward": KEY_W, "back": KEY_S, "left": KEY_A, "right": KEY_D, "jump": KEY_SPACE, "slide": KEY_SHIFT, "reload": KEY_R, "swap": KEY_Q, "pause": KEY_ESCAPE}
	for key in actions:
		InputMap.add_action(key)
		var event := InputEventKey.new()
		event.physical_keycode = actions[key]
		InputMap.action_add_event(key, event)
	InputMap.add_action("fire")
	var click := InputEventMouseButton.new()
	click.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("fire", click)

func create_theme() -> void:
	ui_theme = Theme.new()
	ui_theme.default_font_size = 19
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color("263943")
	normal.set_corner_radius_all(9)
	normal.content_margin_left = 18
	normal.content_margin_right = 18
	normal.content_margin_top = 9
	normal.content_margin_bottom = 9
	var hover := normal.duplicate()
	hover.bg_color = Color("3c5561")
	var pressed := normal.duplicate()
	pressed.bg_color = Color("576755")
	for type in ["Button", "OptionButton"]:
		ui_theme.set_stylebox("normal", type, normal)
		ui_theme.set_stylebox("hover", type, hover)
		ui_theme.set_stylebox("pressed", type, pressed)
		ui_theme.set_color("font_color", type, Color("f4eddd"))
	var panel := normal.duplicate()
	panel.bg_color = Color(0.055, 0.09, 0.115, 0.97)
	panel.content_margin_left = 28
	panel.content_margin_right = 28
	panel.content_margin_top = 20
	panel.content_margin_bottom = 20
	ui_theme.set_stylebox("panel", "PanelContainer", panel)

func menu_panel(title: String, subtitle: String) -> VBoxContainer:
	if is_instance_valid(menu):
		menu.queue_free()
	menu = Control.new()
	menu.theme = ui_theme
	layer.add_child(menu)
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new()
	shade.color = Color(0.025, 0.04, 0.06, 0.60)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu.add_child(shade)
	var margin := MarginContainer.new()
	menu.add_child(margin)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 20)
	margin.add_theme_constant_override("margin_left", 60)
	margin.add_theme_constant_override("margin_right", 60)
	var center := CenterContainer.new()
	margin.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size.x = 570
	center.add_child(panel)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(514, 610)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 12)
	scroll.add_child(box)
	add_label(box, title, 34, Color("e4c17b"))
	add_label(box, subtitle, 16, Color("a8bec5"))
	var separator := HSeparator.new()
	box.add_child(separator)
	return box

func add_label(parent: Node, text: String, font_size: int = 18, color: Color = Color("edf1ed")) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	parent.add_child(label)
	return label

func button(parent: Node, text: String, callback: Callable) -> Button:
	var result := Button.new()
	result.text = text
	result.custom_minimum_size.y = 47
	result.pressed.connect(callback)
	parent.add_child(result)
	return result

func option(parent: Node, label: String, values: Array, selected: int, callback: Callable) -> OptionButton:
	var row := HBoxContainer.new()
	parent.add_child(row)
	var caption := add_label(row, label, 18)
	caption.custom_minimum_size.x = 145
	var result := OptionButton.new()
	result.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	result.custom_minimum_size.y = 43
	for value in values:
		result.add_item(str(value))
	result.select(selected)
	result.item_selected.connect(callback)
	row.add_child(result)
	return result

func show_main_menu() -> void:
	get_tree().paused = false
	playing = false
	hud.editing = false
	hud.reset_input()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	menu_camera.current = true
	refresh_preview()
	var box := menu_panel("GALPÃO / HORA EXTRA", "FPS MOBILE  •  OFFLINE OU SALA ONLINE  •  IPHONE")
	add_label(box, "O expediente acabou. A disputa, não.", 20)
	option(box, "Modo", ["Mata-Mata / FFA", "Equipes / TDM", "Rouba Bandeira / CTF"], mode, func(i): mode = i)
	option(box, "Time / arsenal", ["Vermelho", "Azul"], selected_team, func(i): selected_team = i; refresh_preview())
	option(box, "Personagem", ["A • O entregador", "B • O suporte", "C • A gerente", "D • O conferente"], selected_character, func(i):
		selected_character = i
		custom_character = A.PRESETS[i].duplicate(true)
		refresh_preview()
	)
	button(box, "PERSONALIZAR PERSONAGEM", show_creator)
	var play := button(box, "BATER O PONTO  →  JOGAR", start_match)
	play.add_theme_color_override("font_color", Color("f6d78b"))
	button(box, "JOGAR COM AMIGO ONLINE", show_online_menu)
	button(box, "CONTROLES E CONFIGURAÇÕES", func(): show_settings(false))
	add_label(box, "Toque: mover à esquerda • mirar à direita\nPC: WASD • mouse • espaço • Shift • R • Q • Esc", 15, Color("a8bec5"))
	add_label(box, "Personagens e objetos em 3D feitos com geometria simples.", 13, Color("8299a3"))

func show_online_menu(message: String = "") -> void:
	var box := menu_panel("SALA ONLINE", "Host cria a sala. O amigo entra usando IP e porta.")
	if not message.is_empty():
		add_label(box, message, 17, Color("e4c17b"))
	var local_ip := ""
	for address in IP.get_local_addresses():
		if not address.begins_with("127.") and address.count(".") == 3:
			local_ip = address
			break
	add_label(box, "Para a mesma rede Wi-Fi, use: " + (local_ip if not local_ip.is_empty() else "IP local indisponível") + ":" + str(ONLINE_PORT), 16, Color("a8bec5"))
	button(box, "CRIAR SALA", create_online_room)
	add_label(box, "Entrar em sala", 20, Color("e4c17b"))
	var address_input := LineEdit.new()
	address_input.placeholder_text = "Link da sala  •  exemplo: wss://servidor.onrender.com"
	if OS.has_feature("web") and not PUBLIC_SERVER_URL.is_empty():
		address_input.text = PUBLIC_SERVER_URL
	address_input.custom_minimum_size.y = 44
	box.add_child(address_input)
	button(box, "ENTRAR NA SALA", func(): join_online_room(address_input.text.strip_edges()))
	add_label(box, "No servidor público, cole o link da sala. Na mesma rede Wi-Fi, use o IP local.", 15, Color("a8bec5"))
	button(box, "VOLTAR", show_main_menu)

func create_online_room() -> void:
	var peer := WebSocketMultiplayerPeer.new()
	var result := peer.create_server(server_port)
	if result != OK:
		show_online_menu("Não foi possível abrir a porta " + str(server_port) + ".")
		return
	multiplayer.multiplayer_peer = peer
	online_mode = true
	online_host = true
	show_online_waiting()

func join_online_room(address: String) -> void:
	if address.is_empty():
		show_online_menu("Digite o IP enviado pelo host.")
		return
	var peer := WebSocketMultiplayerPeer.new()
	var endpoint := address if address.begins_with("ws://") or address.begins_with("wss://") else "ws://" + address + ":" + str(ONLINE_PORT)
	var result := peer.create_client(endpoint)
	if result != OK:
		show_online_menu("Não foi possível iniciar a conexão.")
		return
	multiplayer.multiplayer_peer = peer
	online_mode = true
	online_host = false
	var box := menu_panel("CONECTANDO", "Conectando a " + endpoint + "…")
	button(box, "CANCELAR", stop_online_and_menu)

func show_online_waiting() -> void:
	var ip := ""
	for address in IP.get_local_addresses():
		if not address.begins_with("127.") and address.count(".") == 3:
			ip = address
			break
	var box := menu_panel("SALA CRIADA", "Aguardando um amigo entrar.")
	add_label(box, "Envie para ele: " + (ip if not ip.is_empty() else "seu IP") + ":" + str(ONLINE_PORT), 24, Color("e4c17b"))
	add_label(box, "Modo selecionado: " + mode_name(), 17)
	button(box, "CANCELAR SALA", stop_online_and_menu)

func stop_online_and_menu() -> void:
	if multiplayer.multiplayer_peer:
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	online_mode = false
	online_host = false
	show_main_menu()

func refresh_preview() -> void:
	if is_instance_valid(preview):
		preview.queue_free()
	preview = A.character(self, custom_character, selected_team, selected_character == 3)
	preview.position = Vector3(4.3, 0, 5)
	preview.scale = Vector3.ONE * 1.65
	preview.rotation.y = PI * 0.6

func show_creator() -> void:
	var box := menu_panel("SEU PERSONAGEM", "Escolha um preset no menu e ajuste sua aparência.")
	var name_input := LineEdit.new()
	name_input.text = player_name
	name_input.max_length = 18
	name_input.placeholder_text = "Seu nome"
	name_input.custom_minimum_size.y = 44
	name_input.text_changed.connect(func(value): player_name = value)
	box.add_child(name_input)
	option(box, "Corpo", ["Masculino", "Feminino"], custom_character.body, func(i): custom_character.body = i; refresh_preview())
	option(box, "Cabelo", ["Curto", "Gorro", "Coque"], custom_character.hair, func(i): custom_character.hair = i; refresh_preview())
	option(box, "Barba", ["Sem barba", "Com barba"], int(custom_character.beard), func(i): custom_character.beard = i == 1; refresh_preview())
	option(box, "Óculos", ["Sem óculos", "Com óculos"], int(custom_character.glasses), func(i): custom_character.glasses = i == 1; refresh_preview())
	var coats := [Color("714b39"), Color("242936"), Color("59654a"), Color("4b5847"), Color("a57941")]
	option(box, "Roupa", ["Marrom", "Preta", "Verde", "Oliva", "Mostarda"], maxi(0, coats.find(custom_character.coat)), func(i): custom_character.coat = coats[i]; refresh_preview())
	var skins := [Color("e0b08a"), Color("ce9870"), Color("b57e59"), Color("aa7657"), Color("9d6747"), Color("694934")]
	option(box, "Pele", ["01", "02", "03", "04", "05", "06"], maxi(0, skins.find(custom_character.skin)), func(i): custom_character.skin = skins[i]; refresh_preview())
	button(box, "SALVAR E VOLTAR", func(): save_settings(); show_main_menu())

func show_settings(from_match: bool) -> void:
	var box := menu_panel("CONFIGURAÇÕES", "Preferências salvas automaticamente neste aparelho.")
	var sensitivity_label := add_label(box, "Sensibilidade: %.2f" % sensitivity)
	var slider := HSlider.new()
	slider.min_value = 0.25
	slider.max_value = 2.5
	slider.step = 0.05
	slider.value = sensitivity
	slider.custom_minimum_size.y = 42
	slider.value_changed.connect(func(value): sensitivity = value; sensitivity_label.text = "Sensibilidade: %.2f" % value; save_settings())
	box.add_child(slider)
	option(box, "Gráficos", ["Low / economia", "Med / equilibrado", "High / sombras"], graphics, func(i): graphics = i; apply_graphics(); save_settings())
	add_label(box, "Volume")
	var volume := HSlider.new()
	volume.min_value = 0
	volume.max_value = 1
	volume.step = 0.05
	volume.value = master_volume
	volume.custom_minimum_size.y = 42
	volume.value_changed.connect(func(value): master_volume = value; AudioServer.set_bus_volume_db(0, linear_to_db(maxf(value, 0.001))); save_settings())
	box.add_child(volume)
	add_label(box, "Mira fixa no centro • movimento com aceleração\nArraste o lado direito para olhar e mirar.", 17, Color("a8bec5"))
	if from_match:
		button(box, "AJUSTAR POSIÇÃO DOS BOTÕES", begin_layout)
	else:
		add_label(box, "Layout: durante a partida → pausa → configurações.", 16, Color("a8bec5"))
	button(box, "RESTAURAR LAYOUT PADRÃO", func(): hud.layout = Hud.DEFAULT_LAYOUT.duplicate(); save_settings())
	button(box, "VOLTAR", show_pause_menu if from_match else show_main_menu)

func begin_layout() -> void:
	menu.queue_free()
	menu = null
	hud.editing = true
	hud.visible = true
	hud.reset_input()

func finish_layout() -> void:
	hud.editing = false
	hud.reset_input()
	save_settings()
	show_settings(true)

func apply_graphics() -> void:
	get_viewport().scaling_3d_scale = [0.65, 0.85, 1.0][graphics]
	get_viewport().msaa_3d = Viewport.MSAA_2X if graphics == 2 else Viewport.MSAA_DISABLED
	arena.sun.shadow_enabled = graphics == 2
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(master_volume, 0.001)))

func save_settings() -> void:
	var file := ConfigFile.new()
	file.set_value("settings", "sensitivity", sensitivity)
	file.set_value("settings", "graphics", graphics)
	file.set_value("settings", "volume", master_volume)
	file.set_value("settings", "layout", hud.layout)
	file.set_value("character", "preset", selected_character)
	file.set_value("character", "appearance", custom_character)
	file.set_value("character", "name", player_name)
	file.save(settings_path)

func load_settings() -> void:
	var file := ConfigFile.new()
	if file.load(settings_path) != OK:
		return
	sensitivity = clampf(float(file.get_value("settings", "sensitivity", 1.0)), 0.25, 2.5)
	graphics = clampi(int(file.get_value("settings", "graphics", 1)), 0, 2)
	master_volume = clampf(float(file.get_value("settings", "volume", 0.7)), 0, 1)
	var saved_layout = file.get_value("settings", "layout", {})
	if saved_layout is Dictionary:
		for key in Hud.DEFAULT_LAYOUT:
			if saved_layout.get(key) is Vector2:
				hud.layout[key] = saved_layout[key].clamp(Vector2(0.07, 0.20), Vector2(0.93, 0.90))
	selected_character = clampi(int(file.get_value("character", "preset", 0)), 0, 3)
	custom_character = A.PRESETS[selected_character].duplicate(true)
	var appearance = file.get_value("character", "appearance", {})
	if appearance is Dictionary:
		for key in custom_character:
			if appearance.has(key) and typeof(appearance[key]) == typeof(custom_character[key]):
				custom_character[key] = appearance[key]
	player_name = str(file.get_value("character", "name", "Você")).left(18)

func start_match(server_only: bool = false) -> void:
	get_tree().paused = false
	for actor in actors:
		actor.free()
	actors.clear()
	if is_instance_valid(preview):
		preview.visible = false
	if is_instance_valid(menu):
		menu.queue_free()
		menu = null
	scores = [0, 0]
	time_left = 240.0
	for index in range(2):
		reset_flag(index)
		flags[index].node.visible = mode == 2
	player = null
	if not server_only:
		player = make_actor(selected_team, true, selected_character, player_name if not player_name.strip_edges().is_empty() else "Você")
		player.network_id = multiplayer.get_unique_id() if online_mode else 1
	if not online_mode:
		var names := ["Zé do Palete", "Dona Hora Extra", "Wi-Fi do Galpão", "Clóvis da Nota", "Fiscal do Café"]
		for i in range(5):
			var team := 1 - selected_team if i < 3 else selected_team
			make_actor(team, false, i % 4, names[i])
	playing = true
	hud.reset_input()
	hud.visible = not server_only
	if not server_only and not (OS.has_feature("ios") or OS.has_feature("android")):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if not server_only:
		notify("O ponto foi batido. Bora trabalhar!")

func make_actor(team: int, human: bool, preset: int, actor_name: String, appearance: Dictionary = {}, remote: bool = false, owner_id: int = 1) -> Fighter:
	var actor := Fighter.new()
	actor.game = self
	actor.team = team
	actor.is_player = human
	actor.nickname = actor_name
	actor.character_index = preset
	actor.character_config = custom_character.duplicate(true) if human else (appearance.duplicate(true) if not appearance.is_empty() else A.PRESETS[preset].duplicate(true))
	actor.network_remote = remote
	actor.network_id = owner_id
	add_child(actor)
	actors.append(actor)
	actor.position = choose_spawn(actor)
	actor.rotation.y = -PI / 2 if team == 0 else PI / 2
	return actor

func choose_spawn(actor) -> Vector3:
	var result := Vector3.ZERO
	var best := -1.0
	for i in range(20):
		var p: Vector3
		if mode == 0:
			p = Vector3(randf_range(-26, 26), 0.1, randf_range(-17, 17))
		else:
			p = arena.spawn_points[actor.team] + Vector3(randf_range(-2.2, 2.2), 0, randf_range(-3, 3))
		var cell := world_cell(p)
		if navigation.is_point_solid(cell):
			continue
		var distance := 1000.0
		for other in actors:
			if other != actor and other.alive:
				distance = minf(distance, p.distance_to(other.position))
		if distance > best:
			best = distance
			result = p
	return result

func enemies(a, b) -> bool:
	return a != b and (mode == 0 or a.team != b.team)

func _process(delta: float) -> void:
	for trace in traces:
		if trace.time > 0:
			trace.time -= delta
			trace.mesh.visible = trace.time > 0
	if not playing:
		if is_instance_valid(preview):
			preview.rotation.y += delta * 0.18
		return
	notice_timer = maxf(0, notice_timer - delta)
	time_left = maxf(0, time_left - delta)
	if online_mode:
		network_timer -= delta
		if online_host and network_timer <= 0:
			network_timer = 0.05
			sync_online_state.rpc(online_state_packet())
		elif not online_host and network_timer <= 0 and is_instance_valid(player):
			network_timer = 0.05
			send_online_state.rpc_id(1, {"position": player.position, "rotation": player.rotation.y, "pitch": player.pitch})
	if mode == 2 and (not online_mode or online_host):
		update_flags(delta)
	if (not online_mode or online_host) and (time_left <= 0 or (mode == 0 and leading_kills() >= 20) or (mode == 1 and maxi(scores[0], scores[1]) >= 40) or (mode == 2 and maxi(scores[0], scores[1]) >= 3)):
		end_match()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and playing:
		if get_tree().paused:
			resume_game()
		else:
			pause_game()
	if not playing or get_tree().paused or not is_instance_valid(player):
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.device != -1:
		desktop_fire = event.pressed
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		player.look(event.relative)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and playing and is_instance_valid(hud):
		pause_game()

func pause_game() -> void:
	if not playing:
		return
	desktop_fire = false
	hud.reset_input()
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	show_pause_menu()

func show_pause_menu() -> void:
	var box := menu_panel("INTERVALO", "A partida está pausada.")
	button(box, "VOLTAR AO EXPEDIENTE", resume_game)
	button(box, "CONFIGURAÇÕES", func(): show_settings(true))
	button(box, "RECOMEÇAR PARTIDA", start_match)
	button(box, "SAIR PARA O MENU", leave_match)
	add_label(box, "Objetivo: " + objective_text(), 17)

func resume_game() -> void:
	hud.editing = false
	hud.reset_input()
	if is_instance_valid(menu):
		menu.queue_free()
		menu = null
	get_tree().paused = false
	if not (OS.has_feature("ios") or OS.has_feature("android")):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func leave_match() -> void:
	if online_mode:
		stop_online_and_menu()
		return
	playing = false
	for actor in actors:
		actor.queue_free()
	actors.clear()
	player = null
	for i in range(2):
		reset_flag(i)
		flags[i].node.visible = false
	show_main_menu()

func end_match() -> void:
	playing = false
	hud.reset_input()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var winner := "EMPATE"
	if mode == 0:
		var ordered := actors.duplicate()
		ordered.sort_custom(func(a, b): return a.kills > b.kills)
		winner = "VENCEU: " + ordered[0].nickname
		if ordered[0].kills == ordered[1].kills:
			winner = "EMPATE NA LIDERANÇA"
	elif scores[0] != scores[1]:
		winner = "VITÓRIA VERMELHA" if scores[0] > scores[1] else "VITÓRIA AZUL"
	var box := menu_panel("FIM DO EXPEDIENTE", winner)
	add_label(box, mode_name() + "  /  %d : %d" % [scores[0], scores[1]] if mode != 0 else "CLASSIFICAÇÃO INDIVIDUAL", 21, Color("e4c17b"))
	var ordered := actors.duplicate()
	ordered.sort_custom(func(a, b): return a.kills > b.kills)
	for actor in ordered:
		add_label(box, "%s   •   %d abates / %d mortes" % [actor.nickname, actor.kills, actor.deaths], 18)
	button(box, "MAIS UM TURNO", start_match)
	button(box, "MENU", leave_match)

func mode_name() -> String:
	return ["MATA-MATA", "EQUIPES", "ROUBA BANDEIRA"][mode]

func objective_text() -> String:
	return ["20 eliminações para vencer", "40 eliminações por equipe • sem fogo amigo", "3 capturas • sua bandeira deve estar na base"][mode]

func leading_kills() -> int:
	var result := 0
	for actor in actors:
		result = maxi(result, actor.kills)
	return result

func notify(text: String) -> void:
	notice_text = text
	notice_timer = 3.0

func actor_died(victim, attacker) -> void:
	if victim.carried_flag >= 0:
		var flag: Dictionary = flags[victim.carried_flag]
		flag.carrier = null
		flag.dropped = true
		flag.timer = 18.0
		flag.node.position = Vector3(victim.position.x, 0.1, victim.position.z)
		victim.carried_flag = -1
	if is_instance_valid(attacker) and attacker != victim:
		attacker.kills += 1
		if mode == 1:
			scores[attacker.team] += 1
		notify(attacker.nickname + " mandou " + victim.nickname + " tomar um café.")

func _on_connected_to_server() -> void:
	request_online_join.rpc_id(1, custom_character, selected_character, player_name.left(18))

func _on_connection_failed() -> void:
	online_mode = false
	online_host = false
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	show_online_menu("Não foi possível conectar. Confira o IP, a porta e a rede.")

func _on_peer_connected(_peer_id: int) -> void:
	if online_host:
		notify("Amigo conectado. Preparando partida…")

func _on_peer_disconnected(_peer_id: int) -> void:
	if online_mode:
		notify("O amigo saiu da sala.")
		if online_host and playing:
			end_match()
		elif not online_host:
			stop_online_and_menu()

func start_dedicated_server() -> void:
	var port_text := OS.get_environment("PORT")
	if not port_text.is_empty() and port_text.is_valid_int():
		server_port = int(port_text)
	dedicated_server = true
	online_mode = true
	online_host = true
	hud.visible = false
	var peer := WebSocketMultiplayerPeer.new()
	var result := peer.create_server(server_port)
	if result != OK:
		push_error("Não foi possível abrir a porta do servidor: " + str(server_port))
		get_tree().quit(1)
		return
	multiplayer.multiplayer_peer = peer
	print("GALPAO_SERVER_READY port=" + str(server_port))

@rpc("any_peer", "reliable")
func request_online_join(profile: Dictionary, preset: int, display_name: String) -> void:
	if not online_host:
		return
	var peer_id := multiplayer.get_remote_sender_id()
	if peer_id <= 1:
		return
	if dedicated_server:
		if playing or waiting_players.any(func(item): return int(item.id) == peer_id):
			return
		waiting_players.append({"id": peer_id, "profile": profile, "preset": clampi(preset, 0, 3), "name": display_name.left(18), "team": waiting_players.size() % 2})
		notify(display_name.left(18) + " entrou na fila.")
		if waiting_players.size() >= 2:
			start_dedicated_match()
		return
	if playing:
		return
	start_match()
	var remote_team := 1 - selected_team
	var remote := make_actor(remote_team, false, clampi(preset, 0, 3), display_name.left(18), profile, true, peer_id)
	remote.network_target_position = remote.position
	begin_online_match.rpc_id(peer_id, custom_character, selected_team, selected_character, player_name, mode)
	online_status = "friend_joined"
	notify(display_name.left(18) + " entrou no galpão.")

@rpc("authority", "reliable")
func begin_online_match(host_profile: Dictionary, host_team: int, host_preset: int, host_name: String, match_mode: int) -> void:
	online_mode = true
	online_host = false
	mode = match_mode
	selected_team = 1 - host_team
	start_match()
	var remote := make_actor(host_team, false, clampi(host_preset, 0, 3), host_name.left(18), host_profile, true, 1)
	remote.network_target_position = remote.position
	online_status = "joined"
	notify("Partida online iniciada.")

func start_dedicated_match() -> void:
	start_match(true)
	var roster: Array = []
	for item in waiting_players:
		var actor := make_actor(int(item.team), false, int(item.preset), str(item.name), item.profile, true, int(item.id))
		actor.network_target_position = actor.position
		roster.append({"id": int(item.id), "team": int(item.team), "preset": int(item.preset), "name": str(item.name), "profile": item.profile})
	for item in waiting_players:
		begin_dedicated_match.rpc_id(int(item.id), roster, mode)
	waiting_players.clear()
	notify("Partida pública iniciada.")

@rpc("authority", "reliable")
func begin_dedicated_match(roster: Array, match_mode: int) -> void:
	online_mode = true
	online_host = false
	mode = match_mode
	var my_id := multiplayer.get_unique_id()
	for item in roster:
		if int(item.get("id", -1)) == my_id:
			selected_team = int(item.get("team", 0))
	start_match()
	for item in roster:
		if int(item.get("id", -1)) == my_id:
			continue
		var remote := make_actor(int(item.get("team", 0)), false, clampi(int(item.get("preset", 0)), 0, 3), str(item.get("name", "Amigo")), item.get("profile", {}), true, int(item.get("id", -1)))
		remote.network_target_position = remote.position
	online_status = "joined_public"
	notify("Partida pública iniciada.")

@rpc("any_peer", "unreliable")
func send_online_state(state: Dictionary) -> void:
	if not online_host or not playing:
		return
	var actor = actor_by_network_id(multiplayer.get_remote_sender_id())
	if actor == null or not actor.network_remote:
		return
	var requested: Vector3 = state.get("position", actor.position)
	requested.x = clampf(requested.x, -28.0, 28.0)
	requested.z = clampf(requested.z, -19.0, 19.0)
	actor.network_target_position = requested
	actor.network_target_rotation = float(state.get("rotation", actor.rotation.y))

func report_online_shot(origin: Vector3, direction: Vector3, weapon_slot: int) -> void:
	if online_mode and not online_host:
		online_shot.rpc_id(1, origin, direction, weapon_slot)

@rpc("any_peer", "unreliable")
func online_shot(origin: Vector3, direction: Vector3, weapon_slot: int) -> void:
	if not online_host or not playing:
		return
	var shooter = actor_by_network_id(multiplayer.get_remote_sender_id())
	if shooter == null or not shooter.alive:
		return
	shooter.slot = clampi(weapon_slot, 0, shooter.loadout.size() - 1)
	var query := PhysicsRayQueryParameters3D.create(origin, origin + direction.normalized() * 90.0, 3, [shooter.get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and hit.collider.has_method("take_damage"):
		var target = hit.collider
		if enemies(shooter, target):
			var head: bool = hit.position.y - target.global_position.y > 1.43
			target.take_damage(float(shooter.weapon().damage) * (1.6 if head else 1.0), shooter)
	tracer(origin + direction.normalized() * 0.6, hit.position if not hit.is_empty() else origin + direction.normalized() * 55.0, shooter.team)

func online_state_packet() -> Dictionary:
	var actor_state: Array = []
	for actor in actors:
		actor_state.append({"id": actor.network_id, "position": actor.position, "rotation": actor.rotation.y, "hp": actor.hp, "alive": actor.alive, "kills": actor.kills, "deaths": actor.deaths, "flag": actor.carried_flag})
	var flag_state: Array = []
	for flag in flags:
		flag_state.append({"position": flag.node.position, "dropped": flag.dropped, "carrier": flag.carrier.network_id if is_instance_valid(flag.carrier) else -1})
	return {"actors": actor_state, "flags": flag_state, "scores": scores, "time": time_left}

@rpc("authority", "unreliable")
func sync_online_state(packet: Dictionary) -> void:
	if online_host:
		return
	scores = packet.get("scores", scores)
	time_left = float(packet.get("time", time_left))
	for state in packet.get("actors", []):
		var actor = actor_by_network_id(int(state.get("id", -1)))
		if actor != null:
			actor.apply_network_state(state, actor == player)
	var flag_state: Array = packet.get("flags", [])
	for index in range(mini(flags.size(), flag_state.size())):
		var flag: Dictionary = flags[index]
		var state: Dictionary = flag_state[index]
		flag.node.position = state.get("position", flag.node.position)
		flag.dropped = bool(state.get("dropped", false))
		flag.carrier = actor_by_network_id(int(state.get("carrier", -1)))

func actor_by_network_id(id: int):
	for actor in actors:
		if actor.network_id == id:
			return actor
	return null

func tracer(from: Vector3, to: Vector3, team: int) -> void:
	if from.distance_to(to) < 0.01:
		return
	var item: Dictionary = traces[trace_cursor]
	trace_cursor = (trace_cursor + 1) % traces.size()
	var beam: MeshInstance3D = item.mesh
	beam.position = (from + to) / 2
	beam.look_at(to, Vector3.UP if absf((to - from).normalized().y) < 0.99 else Vector3.RIGHT)
	beam.scale.z = from.distance_to(to)
	beam.material_override = A.mat(A.RED.lightened(0.35) if team == 0 else A.BLUE.lightened(0.35), true)
	beam.visible = true
	item.time = 0.05

func build_navigation() -> void:
	navigation.region = Rect2i(0, 0, 39, 27)
	navigation.cell_size = Vector2(1.5, 1.5)
	navigation.offset = Vector2(-28.5, -19.5)
	navigation.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	navigation.update()
	for x in range(39):
		for z in range(27):
			var point := navigation.get_point_position(Vector2i(x, z))
			for obstacle in arena.obstacles:
				if obstacle.has_point(point):
					navigation.set_point_solid(Vector2i(x, z))
					break

func world_cell(pos: Vector3) -> Vector2i:
	return Vector2i(roundi((pos.x + 28.5) / 1.5), roundi((pos.z + 19.5) / 1.5)).clamp(Vector2i.ZERO, Vector2i(38, 26))

func free_cell(cell: Vector2i) -> Vector2i:
	if not navigation.is_point_solid(cell):
		return cell
	for radius in range(1, 6):
		for x in range(-radius, radius + 1):
			for y in range(-radius, radius + 1):
				var candidate := cell + Vector2i(x, y)
				if navigation.is_in_boundsv(candidate) and not navigation.is_point_solid(candidate):
					return candidate
	return cell

func find_path(from: Vector3, to: Vector3) -> PackedVector3Array:
	var points := navigation.get_point_path(free_cell(world_cell(from)), free_cell(world_cell(to)))
	var result := PackedVector3Array()
	for p in points:
		result.append(Vector3(p.x, 0.1, p.y))
	return result

func bot_goal(actor) -> Vector3:
	if mode == 2:
		if actor.carried_flag >= 0:
			return arena.spawn_points[actor.team]
		var own: Dictionary = flags[actor.team]
		if own.dropped:
			return own.node.position
		if is_instance_valid(own.carrier):
			return own.carrier.position
		var enemy: Dictionary = flags[1 - actor.team]
		if is_instance_valid(enemy.carrier):
			return enemy.carrier.position + Vector3(2, 0, 2)
		return enemy.node.position
	var goal: Vector3 = Vector3.ZERO
	var distance := INF
	for other in actors:
		if other.alive and enemies(actor, other):
			var d: float = actor.position.distance_squared_to(other.position)
			if d < distance:
				distance = d
				goal = other.position
	return goal

func create_flags() -> void:
	for team in range(2):
		var root := Node3D.new()
		add_child(root)
		A.box(root, Vector3(0, 1.1, 0), Vector3(0.065, 2.2, 0.065), Color("c6c9bd"))
		A.box(root, Vector3(0.5, 1.85, 0), Vector3(0.95, 0.65, 0.04), A.RED if team == 0 else A.BLUE, false, true)
		flags.append({"node": root, "carrier": null, "dropped": false, "timer": 0.0})
		reset_flag(team)
		root.visible = false

func reset_flag(team: int) -> void:
	var flag: Dictionary = flags[team]
	if is_instance_valid(flag.carrier):
		flag.carrier.carried_flag = -1
	flag.carrier = null
	flag.dropped = false
	flag.timer = 0.0
	flag.node.position = arena.spawn_points[team]

func update_flags(delta: float) -> void:
	for team in range(2):
		var flag: Dictionary = flags[team]
		if is_instance_valid(flag.carrier):
			flag.node.position = flag.carrier.position + Vector3(0, 0.8, 0.35)
			var carrier = flag.carrier
			var own: Dictionary = flags[carrier.team]
			if carrier.position.distance_to(arena.spawn_points[carrier.team]) < 2.4 and not own.dropped and not is_instance_valid(own.carrier):
				scores[carrier.team] += 1
				notify(carrier.nickname + " entregou a encomenda! +1 captura")
				audio.play_sound("capture", -5)
				reset_flag(team)
			continue
		if flag.dropped:
			flag.timer -= delta
			if flag.timer <= 0:
				reset_flag(team)
		for actor in actors:
			if not actor.alive or actor.position.distance_to(flag.node.position) > 1.6:
				continue
			if actor.team == team:
				if flag.dropped:
					reset_flag(team)
					notify(actor.nickname + " recuperou a bandeira.")
			elif actor.carried_flag < 0:
				flag.carrier = actor
				flag.dropped = false
				actor.carried_flag = team
				actor.protection = 0
				notify(actor.nickname + " pegou a encomenda rival!")
				break
