extends Control

const A = preload("res://scripts/assets.gd")
const DEFAULT_LAYOUT := {
	"move": Vector2(0.13, 0.76), "fire": Vector2(0.87, 0.62),
	"jump": Vector2(0.91, 0.82), "slide": Vector2(0.77, 0.84),
	"reload": Vector2(0.70, 0.65), "swap": Vector2(0.59, 0.85)
}
var game
var layout: Dictionary = DEFAULT_LAYOUT.duplicate()
var move_vector := Vector2.ZERO
var fire_held := false
var jump_requested := false
var slide_requested := false
var hit_timer := 0.0
var damage_timer := 0.0
var editing := false
var fingers: Dictionary = {}
var stick_delta := Vector2.ZERO
var mouse_drag := ""
var font: Font = ThemeDB.fallback_font
var scale_factor := 1.0
var safe := Rect2()

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS

func reset_input() -> void:
	move_vector = Vector2.ZERO
	fire_held = false
	jump_requested = false
	slide_requested = false
	fingers.clear()
	stick_delta = Vector2.ZERO

func _process(delta: float) -> void:
	hit_timer = maxf(0, hit_timer - delta)
	damage_timer = maxf(0, damage_timer - delta)
	visible = game.playing or editing
	queue_redraw()

func update_safe() -> void:
	var viewport_size := get_viewport_rect().size
	scale_factor = minf(viewport_size.x / 1280, viewport_size.y / 720)
	safe = Rect2(Vector2(36, 22) * scale_factor, viewport_size - Vector2(72, 44) * scale_factor)
	if OS.has_feature("ios") or OS.has_feature("android"):
		var area := DisplayServer.get_display_safe_area()
		var screen := Vector2(DisplayServer.screen_get_size())
		if screen.x > 0 and screen.y > 0 and area.size.x > 0:
			var ratio := viewport_size / screen
			safe = Rect2(Vector2(area.position) * ratio, Vector2(area.size) * ratio).grow(-14 * scale_factor)

func point(name: String) -> Vector2:
	return safe.position + Vector2(layout[name]) * safe.size

func button_at(pos: Vector2) -> String:
	for key in layout:
		var radius := 80.0 if key == "move" else (53.0 if key == "fire" else 39.0)
		if pos.distance_to(point(key)) <= radius * scale_factor:
			return key
	return ""

func pause_rect() -> Rect2:
	return Rect2(Vector2(safe.end.x - 64 * scale_factor, safe.position.y), Vector2(64, 54) * scale_factor)

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and get_tree().paused and game.playing:
		if editing:
			game.finish_layout()
		else:
			game.resume_game()
		get_viewport().set_input_as_handled()
		return
	if not visible or (get_tree().paused and not editing):
		return
	update_safe()
	if event is InputEventScreenTouch:
		if event.pressed:
			if pause_rect().has_point(event.position):
				if editing:
					game.finish_layout()
				else:
					game.pause_game()
				get_viewport().set_input_as_handled()
				return
			var action := button_at(event.position)
			if action.is_empty() and not editing:
				action = "look" if event.position.x > size.x * 0.38 else "move"
			if action in fingers.values():
				return
			fingers[event.index] = action
			if not editing:
				activate(action)
		else:
			var action: String = fingers.get(event.index, "")
			if action == "move":
				move_vector = Vector2.ZERO
				stick_delta = Vector2.ZERO
			if action == "fire":
				fire_held = false
			fingers.erase(event.index)
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		var action: String = fingers.get(event.index, "")
		if editing and layout.has(action):
			move_button(action, event.position)
		elif action == "move":
			stick_delta = (event.position - point("move")).limit_length(65 * scale_factor)
			move_vector = stick_delta / (65 * scale_factor)
		elif action == "look" or action == "fire":
			if is_instance_valid(game.player):
				game.player.look(event.relative / maxf(scale_factor, 0.1))
		get_viewport().set_input_as_handled()
	elif editing and event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			if pause_rect().has_point(event.position):
				game.finish_layout()
			else:
				mouse_drag = button_at(event.position)
		else:
			mouse_drag = ""
		get_viewport().set_input_as_handled()
	elif editing and event is InputEventMouseMotion and not mouse_drag.is_empty():
		move_button(mouse_drag, event.position)
		get_viewport().set_input_as_handled()

func move_button(action: String, pos: Vector2) -> void:
	var normalized := (pos - safe.position) / safe.size
	layout[action] = normalized.clamp(Vector2(0.07, 0.20), Vector2(0.93, 0.90))

func activate(action: String) -> void:
	match action:
		"fire": fire_held = true
		"jump": jump_requested = true
		"slide": slide_requested = true
		"reload": game.player.reload_weapon()
		"swap": game.player.switch_weapon()

func text_at(text: String, pos: Vector2, font_size: int, color: Color = Color("edf2ee"), centered: bool = false) -> void:
	var actual := maxi(10, int(font_size * scale_factor))
	var p := pos
	if centered:
		p.x -= font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, actual).x / 2
	draw_string(font, p, text, HORIZONTAL_ALIGNMENT_LEFT, -1, actual, color)

func _draw() -> void:
	if not visible:
		return
	update_safe()
	var s := scale_factor
	var dim := Color(0.04, 0.07, 0.09, 0.78)
	var accent := Color("e4c17b")
	if editing:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.04, 0.06, 0.66))
		text_at("ARRASTE OS CONTROLES  •  OK PARA SALVAR", Vector2(size.x / 2, 85 * s), 25, accent, true)
	else:
		var p = game.player
		if not is_instance_valid(p):
			return
		draw_rect(Rect2(safe.position, Vector2(245, 78) * s), dim)
		text_at("HP  %03d" % int(p.hp), safe.position + Vector2(18, 32) * s, 27)
		draw_rect(Rect2(safe.position + Vector2(18, 47) * s, Vector2(208, 7) * s), Color("36424c"))
		draw_rect(Rect2(safe.position + Vector2(18, 47) * s, Vector2(208 * p.hp / 100.0, 7) * s), A.BLUE if p.team == 1 else A.RED)
		var time_text := "%02d:%02d" % [int(game.time_left) / 60, int(game.time_left) % 60]
		text_at(game.mode_name() + "   /   " + time_text, Vector2(size.x / 2, safe.position.y + 25 * s), 20, accent, true)
		var score_text := "%02d   VERMELHO    :    AZUL   %02d" % [game.scores[0], game.scores[1]]
		if game.mode == 0:
			score_text = "%02d ELIMINAÇÕES   /   LÍDER %02d" % [p.kills, game.leading_kills()]
		text_at(score_text, Vector2(size.x / 2, safe.position.y + 54 * s), 22, Color.WHITE, true)
		text_at(game.objective_text(), Vector2(size.x / 2, safe.position.y + 83 * s), 16, Color("bccbd0"), true)
		var center := size * 0.5
		var cross := Color("f6f4df")
		for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
			draw_line(center + direction * 5 * s, center + direction * 12 * s, cross, 2 * s, true)
		draw_circle(center, 1.6 * s, cross)
		if hit_timer > 0:
			for direction in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
				draw_line(center + direction * 13 * s, center + direction * 20 * s, accent, 3 * s, true)
		var bottom := Vector2(size.x / 2, safe.end.y - 16 * s)
		text_at(p.weapon().name + "   %02d / %02d" % [p.magazines[p.slot], p.weapon().mag], bottom, 24, Color.WHITE, true)
		if p.reload_timer > 0:
			text_at("RECARREGANDO", bottom - Vector2(0, 32 * s), 16, accent, true)
		if p.protection > 0:
			text_at("PROTEÇÃO DE RETORNO", center + Vector2(0, 62 * s), 16, A.BLUE, true)
		if p.carried_flag >= 0:
			text_at("COM A BANDEIRA • VOLTE À SUA BASE", center - Vector2(0, 62 * s), 20, accent, true)
		if game.notice_timer > 0:
			text_at(game.notice_text, Vector2(size.x / 2, safe.position.y + 123 * s), 19, accent, true)
		if damage_timer > 0:
			draw_rect(Rect2(Vector2.ZERO, size), Color(0.8, 0.12, 0.09, damage_timer * 0.5))
		if not p.alive:
			draw_rect(Rect2(center - Vector2(265, 55) * s, Vector2(530, 110) * s), dim)
			text_at("PAUSA PARA O CAFÉ", center - Vector2(0, 7 * s), 29, accent, true)
			text_at("Voltando em %d…" % ceili(p.respawn_time), center + Vector2(0, 30 * s), 21, Color.WHITE, true)
	var labels := {"fire": "TIRO", "jump": "PULO", "slide": "SLIDE", "reload": "REC", "swap": "ARMA"}
	for key in layout:
		var pos := point(key)
		var radius := 72.0 if key == "move" else (48.0 if key == "fire" else 35.0)
		var color := Color(0.88, 0.91, 0.89, 0.38)
		if key == "fire":
			color = Color(0.90, 0.75, 0.46, 0.85)
		draw_circle(pos, radius * s, Color(0.05, 0.08, 0.10, 0.37))
		draw_arc(pos, radius * s, 0, TAU, 40, color, 2 * s, true)
		if key == "move":
			draw_circle(pos + stick_delta, 28 * s, Color(0.85, 0.89, 0.86, 0.35))
		else:
			text_at(labels[key], pos + Vector2(0, 6 * s), 16, color, true)
	draw_rect(pause_rect(), dim)
	text_at("OK" if editing else "II", pause_rect().get_center() + Vector2(0, 7 * s), 24, Color.WHITE, true)
