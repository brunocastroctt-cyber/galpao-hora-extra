extends RefCounted

const RED := Color("ef685d")
const BLUE := Color("59b6ed")
const PRESETS := [
	{"name": "A • O entregador", "body": 0, "hair": 0, "beard": true, "glasses": false, "coat": Color("714b39"), "skin": Color("b57e59")},
	{"name": "B • O suporte", "body": 0, "hair": 1, "beard": false, "glasses": true, "coat": Color("242936"), "skin": Color("ce9870")},
	{"name": "C • A gerente", "body": 1, "hair": 2, "beard": false, "glasses": false, "coat": Color("59654a"), "skin": Color("aa7657")},
	{"name": "D • O conferente", "body": 0, "hair": 0, "beard": true, "glasses": false, "coat": Color("4b5847"), "skin": Color("9d6747")}
]
const WEAPONS := [
	{"name": "AK-47", "damage": 25.0, "rate": 0.115, "mag": 30, "reload": 1.9, "spread": 0.014, "burst": 1, "auto": true},
	{"name": "MP5", "damage": 18.0, "rate": 0.078, "mag": 30, "reload": 1.5, "spread": 0.022, "burst": 1, "auto": true},
	{"name": "Calibre 38", "damage": 48.0, "rate": 0.40, "mag": 6, "reload": 2.0, "spread": 0.009, "burst": 1, "auto": false},
	{"name": "M4", "damage": 24.0, "rate": 0.105, "mag": 30, "reload": 1.8, "spread": 0.012, "burst": 1, "auto": true},
	{"name": "Glock Rajada", "damage": 21.0, "rate": 0.32, "mag": 24, "reload": 1.45, "spread": 0.018, "burst": 3, "auto": false},
	{"name": "Glock", "damage": 32.0, "rate": 0.22, "mag": 17, "reload": 1.35, "spread": 0.009, "burst": 1, "auto": false}
]
const WEAPON_MODELS := [
	preload("res://assets/weapons/ak47.glb"),
	preload("res://assets/weapons/mp5.glb"),
	preload("res://assets/weapons/glock.glb"),
	preload("res://assets/weapons/m4.glb"),
	preload("res://assets/weapons/glock.glb"),
	preload("res://assets/weapons/glock.glb")
]
const WEAPON_SCALES := [0.105, 0.068, 0.070, 0.125, 0.070, 0.070]
const WEAPON_YAW := [-90.0, 90.0, 90.0, 90.0, 90.0, 90.0]
static var materials: Dictionary = {}

static func mat(color: Color, glow: bool = false) -> StandardMaterial3D:
	var key := str(color) + str(glow)
	if materials.has(key):
		return materials[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.88
	if glow:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	materials[key] = m
	return m

static func box(parent: Node3D, pos: Vector3, size: Vector3, color: Color, solid: bool = false, glow: bool = false) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var shape := BoxMesh.new()
	shape.size = size
	mesh.mesh = shape
	mesh.material_override = mat(color, glow)
	parent.add_child(mesh)
	mesh.position = pos
	if solid:
		var body := StaticBody3D.new()
		var collision := CollisionShape3D.new()
		var bounds := BoxShape3D.new()
		bounds.size = size
		collision.shape = bounds
		body.add_child(collision)
		mesh.add_child(body)
	return mesh

static func sphere(parent: Node3D, pos: Vector3, radius: float, color: Color, scale_y: float = 1.0) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var shape := SphereMesh.new()
	shape.radius = radius
	shape.height = radius * 2.0
	shape.radial_segments = 10
	shape.rings = 5
	mesh.mesh = shape
	mesh.material_override = mat(color)
	parent.add_child(mesh)
	mesh.position = pos
	mesh.scale.y = scale_y
	return mesh

static func character(parent: Node3D, config: Dictionary, team: int, striped: bool = false) -> Node3D:
	var root := Node3D.new()
	parent.add_child(root)
	var skin: Color = config.skin
	var coat: Color = config.coat
	var feminine: bool = config.body == 1
	var width := 0.47 if feminine else 0.55
	box(root, Vector3(0, 1.02, 0), Vector3(width, 0.65, 0.32), coat)
	box(root, Vector3(0, 1.04, -0.17), Vector3(0.16, 0.57, 0.02), Color("c4c5be") if config.hair == 1 else Color("383e43"))
	for side in [-1, 1]:
		var leg := box(root, Vector3(side * 0.16, 0.40, 0), Vector3(0.22, 0.65, 0.26), Color("303e50"))
		leg.name = "LegL" if side < 0 else "LegR"
		box(root, Vector3(side * 0.16, 0.10, -0.06), Vector3(0.24, 0.16, 0.39), Color("212932"))
		var arm := box(root, Vector3(side * (width / 2 + 0.06), 1.18, -0.12), Vector3(0.18, 0.43, 0.22), Color("b3bdc5") if striped else coat)
		arm.name = "ArmL" if side < 0 else "ArmR"
		arm.rotation.z = -side * 0.48
		var forearm := box(root, Vector3(side * 0.23, 0.98, -0.34), Vector3(0.16, 0.18, 0.34), Color("b3bdc5") if striped else coat)
		forearm.name = "ForearmL" if side < 0 else "ForearmR"
		forearm.rotation.x = -0.35
		box(root, Vector3(side * 0.16, 0.93, -0.48), Vector3(0.14, 0.15, 0.16), skin)
		if striped:
			for row in range(4):
				box(root, Vector3(side * (width / 2 + 0.08), 0.82 + row * 0.12, -0.125), Vector3(0.185, 0.045, 0.01), Color("334359"))
	sphere(root, Vector3(0, 1.56, 0), 0.245, skin, 1.14)
	var hair_color := Color("262325")
	sphere(root, Vector3(0, 1.76, 0.035), 0.245, hair_color, 0.55 if config.hair != 1 else 1.0)
	if config.hair == 2:
		sphere(root, Vector3(0, 1.94, 0.08), 0.17, Color("40302c"))
	if config.beard:
		box(root, Vector3(0, 1.43, -0.17), Vector3(0.30, 0.13, 0.12), hair_color)
	for side in [-1, 1]:
		box(root, Vector3(side * 0.085, 1.59, -0.232), Vector3(0.035, 0.028, 0.02), Color("171d24"))
		if config.glasses:
			box(root, Vector3(side * 0.095, 1.60, -0.242), Vector3(0.15, 0.083, 0.025), Color("202735"))
	box(root, Vector3(0, 1.27, -0.18), Vector3(0.22, 0.085, 0.025), RED if team == 0 else BLUE, false, true)
	return root

static func weapon(parent: Node3D, index: int) -> Node3D:
	var root := Node3D.new()
	parent.add_child(root)
	var model: Node3D = WEAPON_MODELS[index].instantiate()
	root.add_child(model)
	model.scale = Vector3.ONE * WEAPON_SCALES[index]
	model.rotation_degrees = Vector3(0, WEAPON_YAW[index], 0)
	if index == 1:
		tint_model(model, Color("273139"))
	elif index in [2, 4, 5]:
		tint_model(model, Color("242a30"))
	return root

static func tint_model(node: Node, color: Color) -> void:
	if node is MeshInstance3D:
		node.material_override = mat(color)
	for child in node.get_children():
		tint_model(child, color)
